import gradio as gr
import torch
import torchvision.transforms as T
from torchvision.utils import make_grid
import numpy as np

netG_dcgan.eval()
wgan_G.eval()

def generate_single_image(model_choice):
    with torch.no_grad():
        noise = torch.randn(1, 100, 1, 1, device=device)
        
        if model_choice == "DCGAN":
            fake_image = netG_dcgan(noise).cpu()
        elif model_choice == "WGAN-GP":
            fake_image = wgan_G(noise).cpu()
            
        grid = make_grid(fake_image, normalize=True)
        
        ndarr = grid.mul(255).add_(0.5).clamp_(0, 255).permute(1, 2, 0).to('cpu', torch.uint8).numpy()
        return ndarr

interface = gr.Interface(
    fn=generate_single_image,
    inputs=gr.Radio(["DCGAN", "WGAN-GP"], label="Select GAN Model", value="WGAN-GP"),
    outputs=gr.Image(label="Generated Anime Face"), # Updated the label here
    title="Anime Face Generator: DCGAN vs WGAN-GP",
    description="Click 'Submit' to generate a random anime face. Swap between DCGAN and WGAN-GP to test which model produces better quality!",
    allow_flagging="never"
)

interface.launch(share=True)
